The source codes are in src folder.
Just in case, there is debug folder, where the executable exe file of the project is in it with the data.
Eclipse IDE is used to create this project.