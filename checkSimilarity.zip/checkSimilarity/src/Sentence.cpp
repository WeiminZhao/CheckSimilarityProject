/*
 * sentence.cpp
 *
 *  Created on: Nov. 18, 2019
 *      Author: zwmsc
 */

#include "Sentence.h"

namespace Sent {

Sentence::Sentence() {
	// TODO Auto-generated constructor stub

}

Sentence::~Sentence() {
	// TODO Auto-generated destructor stub
}

void Sentence::save_as_vector(string s)
{
	int num=0;
	words.push_back("");
	for(int i=0;i<s.length();i++)
	{
			if(s[i]==' ' && words[words.size()-1]!="" && !words[words.size()-1].empty())
			{
				//////////////normal words check////////////////////
				if(words.size()!=0)
					if(usual.find(words[words.size()-1])!=string::npos)
					{
						words.pop_back();
						num--;
					}
				////////////////////////////////////////

				num++;
				words.push_back("");
			}
			else if(s[i]==' ') ;
			else if(s[i]!=' ')
				words[num]+=s[i];
	}

	//////////////normal words check//////////////////
	if(words.size()!=0)
		if(usual.find(words[words.size()-1])!=string::npos)
			words.pop_back();
	//////////////////////////////////////
}

} /* namespace Dino */
