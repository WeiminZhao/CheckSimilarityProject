/*
 * sentence.h
 *
 *  Created on: Nov. 18, 2019
 *      Author: zwmsc
 */

#ifndef SENTENCE_H_
#define SENTENCE_H_

#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

namespace Sent {

class Sentence {
public:
	Sentence();
	virtual ~Sentence();
	void save_as_vector(string s);
	vector<string> words;//hold the words in a sentence
	vector<int> vs;
private:
	string usual="the of and to a in is you are for that or it as be on your with can have this an by not but at from i they more will if some there what about which when one their all also how many do has most other so was we these may like use into than up out who them make because such through get work even different its no our new just only see used good been need should very any often well were then my first would each find where much take those while before however us his being same why might still too had after since";
};

} /* namespace Dino */

#endif /* SENTENCE_H_ */
