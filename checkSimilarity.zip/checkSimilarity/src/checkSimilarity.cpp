//============================================================================
// Name        : checkSimilarity.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <math.h>
#include <string>
#include <sstream>

#include "Sentence.h"
using namespace std;
using namespace Sent;

int checkMatchNum(string s, vector<string> vstring)
{
	if(s=="") return 0;
	int num=0;
	for(int i=0;i<vstring.size();i++)
	{
		if(s.compare(vstring[i])==0)
			num++;
	}
	return num;
}

double simi(string f1,string f2) {
	string line;
	ifstream file1(f1);
	ifstream file2(f2);


//	string s1="hello world. it is good. i do not know it.";
//	string s2="hello banana. i like it. i do not know.";
	string s1="",s2="";//those string contain all the words in both articles
	char c1,c2;

	if(file1.is_open() && file2.is_open())
	{

		while(file1.get(c1))
		{
			if(isalpha(c1))
				s1+=tolower(c1);
			else if(c1==' '||c1=='!'||c1=='?'||c1=='.'||c1==':'||c1==';')
				s1+=c1;
			else if(isspace(c1))
				s1+=' ';
			else
				s1+=' ';
		}
		s1+='.';
		s1+='\0';
		while(file2.get(c2))
		{
			if(isalpha(c2))
				s2+=tolower(c2);
			else if(c2==' '||c2=='!'||c2=='?'||c2=='.'||c2==':'||c2==';')
				s2+=c2;
			else if(isspace(c2))
				s2+=' ';
			else
				s2+=' ';
		}
		s2+='.';
		s2+='\0';
	}
	file1.close();
	file2.close();

	vector<Sentence> art1;//sentence vector of art 1
	vector<Sentence> art2;//sentence vector of art 2
	//dividing articles into sentences, each word is a value in sentences words vector
	//////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////
	int x=0,newStart=0;
	string stemp="";
	while(s1[x]!='\0'||s1[x]!=0)
	{
		if(s1[x]=='.' ||s1[x]=='!'||s1[x]=='?'||s1[x]==':'||s1[x]==';')//divide a string of content in to sentence by '.'
		{
			for(int num=newStart;num<x;num++)
			{
				stemp+=s1[num];
			}
			newStart=x+1;
			if(stemp!="" && stemp.find_first_not_of(' ') != std::string::npos)//get rid of the possibility of the sentence of null or space
			{
				art1.push_back(Sentence());//save the sentence into article vector as a vector
				art1[art1.size()-1].save_as_vector(stemp);
				/////this part is in case the normal word check remove everything in this sentence, in this case we need to remove sentence
				if(art1[art1.size()-1].words.size()==0)
					art1.pop_back();
				////
			}
			stemp="";
		}

		x++;
	}

	x=0;newStart=0;
	stemp="";
	while(s2[x]!='\0'||s2[x]!=0)
	{
		if(s2[x]=='.' ||s2[x]=='!'||s2[x]=='?'||s2[x]==':'||s2[x]==';')//divide a string of content in to sentence by '.'
		{
			for(int num=newStart;num<x;num++)
			{
				stemp+=s2[num];
			}
			newStart=x+1;

			if(stemp!="" && stemp.find_first_not_of(' ') != std::string::npos)//get rid of the possibility of the sentence of null or space
			{
				art2.push_back(Sentence());//save the sentence into article vector as a vector
				art2[art2.size()-1].save_as_vector(stemp);
				/////this part is in case the normal word check remove everything in this sentence, in this case we need to remove sentence
				if(art2[art2.size()-1].words.size()==0)
					art2.pop_back();
				/////
			}
			stemp="";
		}

		x++;
	}

//	cout<<"words in words vect:=========="<<endl;
//	for(int i=0;i<art1.size()-0;i++)
//	{
//		for(int j=0;j<art1[i].words.size();j++)
//			cout<<art1[i].words[j]<<" :";
//		cout<<"|";
//	}
//	cout<<endl;
//	for(int i=0;i<art2.size()-0;i++)
//	{
//		for(int j=0;j<art2[i].words.size();j++)
//			cout<<art2[i].words[j]<<" :";
//		cout<<"|";
//	}
//	cout<<endl;

	//create word appear vector (record the words have appeared in both articles)
	/////////////////////////////////////////////////////////
	///////////////////////////////////////////////////
	vector<string> word_appear;//record word appear vectors
	word_appear.push_back(art1[0].words[0]);

	for(int i=0;i<art1.size();i++)
	{
		for(int j=0;j<art1[i].words.size();j++)
		{
			if(find(word_appear.begin(),word_appear.end(),art1[i].words[j])==word_appear.end())
			{
				word_appear.push_back(art1[i].words[j]);
			}
		}
	}
	for(int i=0;i<art2.size();i++)
	{
		for(int j=0;j<art2[i].words.size();j++)
		{
			if(find(word_appear.begin(),word_appear.end(),art2[i].words[j])==word_appear.end())
			{
				word_appear.push_back(art2[i].words[j]);
			}
		}
	}

//	cout<<"word_appear========"<<endl;
//	for(int i=0;i<word_appear.size();i++)
//		cout<<word_appear[i]<<"; ";
//	cout<<endl;

	//try to initial all vs here for flexible use(delete this if you want pushback at the compare moment)
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	for(int i=0;i<art1.size();i++)
	{
		for(int j=0;j<word_appear.size();j++)
		{
			art1[i].vs.push_back(0);
		}
	}
	for(int i=0;i<art2.size();i++)
	{
		for(int j=0;j<word_appear.size();j++)
		{
			art2[i].vs.push_back(0);
		}
	}

	//create numeric vector for every sentence (reference to word_appear vector, each value of the vector record the word appear time in this sentence)
	////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	for(int i=0;i<art1.size();i++)
	{
		for(int j=0;j<word_appear.size();j++)
		{
			if(find(art1[i].words.begin(),art1[i].words.end(),word_appear[j])==art1[i].words.end())
			{
				;//art1[i].vs.push_back(0);
			}
			else
				art1[i].vs[j]+=checkMatchNum(word_appear[j],art1[i].words);//1;//art1[i].vs.push_back(1);
		}
	}
	for(int i=0;i<art2.size();i++)
	{
		for(int j=0;j<word_appear.size();j++)
		{
			if(find(art2[i].words.begin(),art2[i].words.end(),word_appear[j])==art2[i].words.end())
			{
				;//art2[i].vs.push_back(0);
			}
			else
				art2[i].vs[j]+=checkMatchNum(word_appear[j],art2[i].words);//1;//art2[i].vs.push_back(1);
		}
	}

//	cout<<"binary vect====="<<endl;
//	for(int i=0;i<art1.size();i++)
//	{
//		for(int j=0;j<art1[i].vs.size();j++)
//			cout<<art1[i].vs[j]<<"";
//		cout<<"|";
//	}
//	cout<<endl;
//	for(int i=0;i<art2.size();i++)
//	{
//		for(int j=0;j<art2[i].vs.size();j++)
//			cout<<art2[i].vs[j]<<"";
//		cout<<"|";
//	}
//	cout<<endl;

	//calculate vector similarity for every sentence
	/////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	int dot=0;
	int suma=0;
	int sumb=0;
	double sim ;
	double maxSim=0;
	double sumMaxSim=0;

	for(int i=0;i<art1.size();i++)
	{
		for(int i2=0;i2<art2.size();i2++)//compare sentences in art1 to art2
		{
			//this for for dot
			for(int j=0;j<word_appear.size();j++)
			{
				dot+=art1[i].vs[j] * art2[i2].vs[j];
				//
			}
			//for sum a^2
			for(int j=0;j<word_appear.size();j++)
			{
				suma+=art1[i].vs[j]*art1[i].vs[j];
				//
			}
			//for sum b^2
			for(int j=0;j<word_appear.size();j++)
			{
				sumb+=art2[i2].vs[j]*art2[i2].vs[j];
				//
			}

			sim =(double)dot/(sqrt(suma)*sqrt(sumb));
			//cout<<sim<<endl;
			dot=0;
			suma=0;
			sumb=0;

			if(maxSim<sim)
				maxSim=sim;
		}
		//cout<<":"<<maxSim<<endl;
		if(maxSim>=0.1)//we only take if the similarity between sentence >=0.x
			sumMaxSim+=maxSim;

		maxSim=0;
		///here art2 end

	}

	cout<<"::"<<sumMaxSim/art1.size()<<endl;

	//return 0;
	return sumMaxSim/art1.size();
}

int main(){
	ofstream ofile("output.csv");
	if(ofile.is_open())
	{
		for(int i=1;i<101;i++)
		{
			for(int j=97;j<=101;j++)
			{
				char c=j+'\0';
				string cs="";
				cs+=c;
				string f1="evaluation/"+to_string(i)+".txt";
				string f2="evaluation/"+cs+".txt";
				cout<<f1<<" "<<f2<<endl;
				ofile<<simi(f1,f2);
				ofile<<',';
			}
			ofile<<"\n";
		}
	}
	ofile.close();

	return 0;
}
